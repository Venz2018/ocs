<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="a398bf04cc609ff95d5e9348477e6de7648c092bbab9aec7a1c2b04ea55ffb8a"
DB_SET="mysql:host=localhost;port=3306;dbname=rebornvp_data"
DB_USER="rebornvp_user"
DB_PASS="Password!"
?>