<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"

?>